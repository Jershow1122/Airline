from django.contrib import admin
from .models import flight_details


# Register your models here.

admin.site.register(flight_details)
